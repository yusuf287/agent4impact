-- Lights Out: one agent-friendly view over REAL open data (Toronto Open Data, checked 2026-10-19).
-- Load first (column names are snake-cased by kit add-data):
--   python -m kit add-data ckan:apartment-building-registration --table buildings
--   python -m kit add-data ckan:apartment-building-evaluation --resource 2023 --table building_eval
-- Then:  python -m kit sql --file domains/lights_out/views.sql
-- Notes: registration has NO coordinates -> join evaluation on rsn for latitude/longitude.
--        no_of_elevators and barrier-free counts are TEXT -> SAFE_CAST. Values are self-reported by owners.
--        is_there_emergency_power has no official definition; treat it as "owner reports emergency power".
--        Legacy duplicate columns (no_of_storeys, no_of_units, ...?) are mostly null: use confirmed_*.
--        If a column name differs after loading, run `python -m kit sql "SELECT * FROM ...buildings LIMIT 1"` and adjust.
CREATE OR REPLACE VIEW `${PROJECT_ID}.${DATASET}.v_tower_risk` AS
WITH ev AS (
  SELECT CAST(rsn AS STRING) AS rsn, ANY_VALUE(SAFE_CAST(latitude AS FLOAT64)) AS latitude, ANY_VALUE(SAFE_CAST(longitude AS FLOAT64)) AS longitude
  FROM `${PROJECT_ID}.${DATASET}.building_eval`
  GROUP BY 1
)
SELECT
  CAST(b.rsn AS STRING) AS rsn,
  b.site_address,
  b.ward,
  b.pcode AS postal_prefix,
  SAFE_CAST(b.confirmed_storeys AS INT64)               AS storeys,
  SAFE_CAST(b.confirmed_units AS INT64)                 AS units,
  SAFE_CAST(b.no_of_elevators AS INT64)                 AS elevators,
  UPPER(CAST(b.is_there_emergency_power AS STRING)) = 'YES' AS reports_emergency_power,
  SAFE_CAST(b.no_barrier_free_accessble_units AS INT64) AS barrier_free_units,
  b.air_conditioning_type,
  b.year_built,
  b.property_type,
  ev.latitude,
  ev.longitude,
  -- Transparent, explainable score (not ML): tall + many homes + no reported emergency power.
  (CASE WHEN UPPER(CAST(b.is_there_emergency_power AS STRING)) = 'YES' THEN 0 ELSE 50 END)
  + LEAST(IFNULL(SAFE_CAST(b.confirmed_storeys AS INT64), 0), 30)
  + LEAST(DIV(IFNULL(SAFE_CAST(b.confirmed_units AS INT64), 0), 20), 20)  AS risk_score
FROM `${PROJECT_ID}.${DATASET}.buildings` b
LEFT JOIN ev ON CAST(b.rsn AS STRING) = ev.rsn
WHERE SAFE_CAST(b.no_of_elevators AS INT64) > 0;
