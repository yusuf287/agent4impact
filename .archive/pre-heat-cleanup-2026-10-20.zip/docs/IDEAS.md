# Ideas — decision rule, ranked list, lead idea, fact sheet

Facts in this file were checked on **2026-10-19** (sources in section 5). Anything not checked says **VERIFY**.

## 1. Decision rule at 9:25 AM
1. Read the challenge + dataset. Underline: **user, decision, hero data**.
2. Pick by theme:
   - emergencies / resilience / vulnerable people / infrastructure → **Lights Out** (with Ready Tower as Act 1)
   - air quality / heat / public health operations → **Smoke Day Desk** (or **Cool Room Check** for heat + housing)
   - food access / supply → **Pantry Forecast + Rescue Match** on the event data
   - anything else / unclear → **SurgeDesk**
3. If the event dataset is rich, make **it** the hero; our open data becomes the second layer.
4. One idea agreed by 9:55. Don't merge two ideas.
5. Write the 5-line demo script first: person · before · trigger · aha · scale.

## 2. Ranked list (my judgement)
Scores 1–5: **F**it with themes · **R**eal data · **B**uildable in 6 h · **W**ow on stage · **O**riginality.

### Leads and fallbacks
| # | Idea | Theme | One line | F | R | B | W | O | Use when |
|---|---|---|---|---|---|---|---|---|---|
| 1 | **Lights Out + Ready Tower** 🆕 | all 3 | *Before* a storm: rank towers and build each one's emergency plan and opt-in contact list from real data. *During* an outage: run one clock for elevators, medical power and food, and propose dispatches for approval | 5 | 4 | 3 | 5 | 4 | emergency / resilience |
| 2 | **Smoke Day Desk** 🆕 | health | Live AQHI forecast → per-site decisions for child-care centres, day camps and shelters (move indoors / cancel / open clean-air space) + multilingual notices, human approves | 3 | 5 | 5 | 3 | 3 | public health / air quality |
| 3 | **Cool Room Check** (was "26°C", corrected) | health + housing | Finds RentSafeTO buildings without cooling in every unit that must now keep an indoor amenity room ≤26°C (since June 1 2026) and drafts tenant notices / inspection lists | 3 | 5 | 4 | 3 | 4 | heat / housing |
| 4 | **SurgeDesk** | any | Triage copilot for a surge of requests; rules rank, LLM explains, human approves | 4 | 2 | 5 | 3 | 2 | generic fallback |
| 5 | **EvacPilot** | evacuation | Hazard zone → vulnerable sites → routes/shelters → approve | 3 | 3 | 3 | 4 | 3 | evacuation-only |
| 6 | **Pantry Forecast + Rescue Match** | food | Forecast pantry shortfalls; match surplus donors | 3 | 3 | 4 | 3 | 3 | food-only |

**Why the new ideas rank where they do**
- **Ready Tower is the real-data half that Lights Out was missing.** Before, the outage, residents and calls were all simulated. "Before the storm" mode runs completely on real open data (registry + evaluations + weather alerts). It produces concrete outputs: a per-building readiness card, a landlord letter, a tenant flyer in several languages, and a digital, opt-in version of the City's own *Voluntary Tenant Contact List* template. Then Act 2 ("the lights go out") uses the same data. One product, two modes; this is not two ideas merged.
- **Smoke Day Desk is the safest strong option.** The data is live, real and needs no key (ECCC AQHI). The decision rule is a published one (TDSB: AQHI 7–10 consider moving indoors, >10 avoid outdoor exertion). The users are clear: child-care operators. It is less original, but very hard to break on stage.
- **Cool Room Check replaces "26°C"** because the original framing was wrong (see fact 3): Toronto has **no** 26°C cap for units without A/C.

### Modules (only if the core works)
| Module | One line | Notes |
|---|---|---|
| **Replay mode** 🆕 | Run Lights Out against the **real July 16 2024 outage** (about 167,000 Toronto Hydro customers at peak, caused by a flooded Hydro One station) hour by hour: "what we would have flagged at 6:15 pm" | Real event, real timeline; the outage *area* is still approximated, so label it |
| **Consent sign-up agent** 🆕 | Multilingual chat/voice sign-up for the opt-in list (L2), with explicit consent text; also points eligible residents to Toronto Hydro's Life Support Notification Program | Pitch stat: Toronto Police's Vulnerable Persons Registry had **305 registrants** after 4+ years (Ombudsman, Sept 2024) |
| Hot Pills / Pill Bottle Passport | Photo of pill bottles → heat-risk card | Never give dose advice |
| Voice front door | Gemini Live in front of the tools | Browser demo only; record a backup |
| One Message, Every Language | One alert → many languages | |
| Silent Neighbours | Escalating check-in loop with approvals | |
| Rumor Control Room | Detect rumours, answer from official sources | |

### Parked (prior art or weak data)
Heat Shield (Naver CareCall exists) · Ground Truth (Ushahidi) · Break the Plan / Dress Rehearsal (heavy) · The Unseen · Lifeline Interpreter · Ripple · Guardian Voice / Quiet Map / T-Minus 72 / Nobody Left Behind / Agent War Room (pieces folded into Lights Out) · Unclaimed Dollars · Dignity Pantry · Evacuee Medicine & Meal Match · Host-City Surge · Next Meal Navigator (many similar bots).

**The winning shape:** a coordinator tool for responders plus resident-facing outputs, a visible agent loop, a human approval step, and honest limits.

## 3. Lead: Lights Out + Ready Tower

**One line.** When the power fails, elevators stop, medical devices run down and food spoils. We find the towers at risk *before* the storm, and run one clock for all three *during* it. A human approves every dispatch.

**Strengths**
- It covers food, health and evacuation without forcing it: one event, three failures.
- The clock is a built-in story (hour 0 → hour 6).
- It is proactive: it finds people who would never call.
- L0 uses no personal data at all.

**Risks and how we handle them**
1. *Simulation.* Hero = the real ranking ("these towers, in this order, because…"), plus Replay of the real July 2024 event. Fake calls are garnish only.
2. *Too big.* Build the thin slice below. 4 specialist agents at most, no phone integration.
3. *Data meaning.* `is_there_emergency_power` is **owner self-reported YES/NO with no official definition**. Say "owner reports no emergency power", not "elevators will stop". Registration has **no coordinates**: join to Evaluations on `rsn`.
4. *Medical safety.* No medical advice. Anything life-threatening → "call 911" + a human.
5. *Prior art (be upfront).* The City already gives landlords a paper Voluntary Tenant Contact List template. Toronto Hydro has a Life Support Notification Program. TPS has a Vulnerable Persons Registry (305 registrants). **Nobody joins them up.** We make them digital, opt-in and coordinated; we don't replace them.
6. *Privacy.* Health information needs explicit opt-in consent (PIPEDA / PHIPA). Use the four contact levels below.
7. *Fit.* Use this only if the challenge is about emergencies or vulnerable people.

**Contact levels.**
- L0: open data only (which towers and floors to check).
- L1: residents call a hotline.
- L2: opt-in sign-up before the storm (QR code in the lobby, consent agent).
- L3: partner lists under agreements.

The agent always says it is automated, and humans approve every dispatch.

**Thin slice (≈ 90 minutes with the kit).**
```
python -m kit use lights_out
python -m kit add-data ckan:apartment-building-registration --table buildings
python -m kit add-data ckan:apartment-building-evaluation --resource 2023 --table building_eval
python -m kit sql --file domains/lights_out/views.sql          # creates v_tower_risk (explainable score)
python -m kit add-data <your outage_zone.csv>                  # SYNTHETIC or Replay-approximated, labelled
python -m kit add-data <your opt_in_residents.csv>             # SYNTHETIC, labelled
python -m kit team-check && python -m kit rehearse && python -m kit ui
```
The team is defined in `domains/lights_out/team.yaml`: scout → (access ‖ medical ‖ food) → coordinator → skeptic → approver (prepares the proposal) → formatter. The **root agent** then asks the human to approve, and the UI shows Approve and Reject buttons.

**Pitch skeleton.**
1. Opener: "305 people. That's how many are on Toronto's vulnerable persons registry, in a city of three million."
2. The clock.
3. Act 1 (before the storm): ranked towers and the readiness card.
4. Act 2 (outage, or a Replay of July 16, 2024): the plan.
5. The skeptic changes one decision.
6. The human approves.
7. What is real and what is simulated.
8. Path to real: Toronto Hydro, Paramedics, TCHC and food banks.
9. Scale: any city with a building registry.

**Open questions.**
- Which data does the event provide?
- Who owns the UI and the map?
- Do the column names match `views.sql` after loading? Run `kit sql "SELECT * FROM …buildings LIMIT 1"` to check.

## 4. Fact sheet: what you can say

| # | Claim | Status | Say this |
|---|---|---|---|
| 1 | Registration dataset | ✅ | "Toronto's Apartment Building Registration: 3,611 buildings, refreshed monthly; owner self-reported" |
| 2 | 905 buildings without emergency power / ~84k homes / 240 at 10–36 storeys | ⚠️ no public source | Only quote the numbers **your own query** returns: "our analysis of City data" |
| 3 | "26°C law" | ⚠️ corrected | "From June 1 2026, buildings that don't cool every unit must keep an indoor amenity room at or below 26°C (Jun 1–Sep 30); if A/C is provided it must keep units ≤26°C. There is no cap yet for units without A/C (report due June 2027)" |
| 4 | Fridge 4 h / freezer 48 h full, 24 h half | ✅ Health Canada | "A closed fridge keeps food cold about 4 hours" |
| 5 | emPOWER | ✅ US only | "The US maps electricity-dependent Medicare patients by ZIP code (HHS emPOWER); Canada has no equivalent" |
| 6 | Toronto Hydro outage data | ✅ no open API | "There is a public outage map but no open data feed, so we simulate or replay" |
| 7 | Daily Bread | ✅ Who's Hungry 2025 | "4.1 million food bank visits, +340% since 2019; 1 in 4 clients are children" |
| 8 | 2025 wildfire evacuations / smoke | ✅ worded carefully | "Over 85,000 people evacuated in 2025 (Public Safety Canada); Toronto briefly had the world's worst air quality on June 6, 2025 (IQAir)" |
| 9 | Naver CareCall | ⚠️ figures vary | "used by over half of Korea's local governments (Naver)" |
| 10 | Heat Relief Network / 311 open data | ✅ / ⚠️ | Both datasets exist; whether heat complaint types appear in the 311 file is unconfirmed |
| 11 | ECCC alerts + AQHI, Open-Meteo | ✅ | No key needed. Open-Meteo's free tier is for non-commercial use only |
| 12 | July 16 2024 outage | ✅ | "About 167,000 Toronto Hydro customers lost power when flooding hit a Hydro One station" |
| 13 | Vulnerable Persons Registry | ✅ | "305 registrants after 4+ years; the Ombudsman found no one in charge of it (Sept 2024)" |
| 14 | TDSB AQHI rule | ✅ (board rule, not Toronto Public Health) | "AQHI 7–10: consider moving indoors; above 10: avoid outdoor exertion" |

## 5. Sources (checked 2026-10-19)
- Registration: https://ckan0.cf.opendata.inter.prod-toronto.ca/api/3/action/package_show?id=apartment-building-registration
- Evaluations (lat/long): …package_show?id=apartment-building-evaluation
- Indoor temperature rules: https://www.toronto.ca/community-people/housing-shelter/rental-housing-tenant-information/rental-housing-standards/indoor-temperatures-in-apartment-units/
- Food safety: https://www.canada.ca/en/health-canada/services/food-drinking-water-safe-emergency.html
- emPOWER: https://empowerprogram.hhs.gov/about-empowermap.html
- Daily Bread: https://www.dailybread.ca/blog/4-1-million-food-bank-visits-reveal-record-depth-of-poverty-in-toronto/
- July 2024 outage: https://toronto.ctvnews.ca/14-people-rescued-from-flooded-don-valley-parkway-in-toronto-290-000-without-power-1.6965390
- Vulnerable Persons Registry: https://www.ombudsmantoronto.ca/news/toronto-ombudsman-finds-major-gaps-with-polices-registry-for-vulnerable-persons/
- Child-care smoke guidance: https://www.toronto.ca/community-people/health-wellness-care/health-programs-advice/air-quality/wildfire-air-quality-strategy/air-quality-and-wildfire-smoke-guidance-for-child-care-centres/ · TDSB: https://www.tdsb.on.ca/Portals/0/EarlyYears/docs/CCS-WildfireSmoke.pdf
- Toronto Hydro Life Support Notification: torontohydro.com (life-support notifications) · Voluntary Tenant Contact List template: toronto.ca (RentSafeTO)
- AQHI / alerts API: https://api.weather.gc.ca/collections · Open-Meteo terms: https://open-meteo.com/en/terms

## 6. New idea template
Name · status · themes · one line · the person and the painful moment · the decision and who approves · hero / extra / simulated data · agents (one reason each) · demo (trigger → aha → scale) · prior art · risks · score (F R B W O) · kit commands · open questions.
