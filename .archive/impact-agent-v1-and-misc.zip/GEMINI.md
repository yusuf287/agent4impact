See AGENTS.md in this folder — it is the single source of project instructions. Follow it exactly.
