# impact-agent: hackathon scaffold for Agents for Impact

A working ADK agent skeleton that turns into any **food equity / public health / evacuation** project
by editing **one file** (`domain.yaml`) and loading your data. Verified against **google-adk 2.12**.

```
impact_agent (root, routing rules from domain.yaml)
 ├─ prioritize_requests      people/cases slot   → explainable, deterministic triage + 911 escalation
 ├─ find_nearest_resources   places slot         → nearest food bank / cool space / shelter / clinic
 ├─ geocode_address          address → lat/lon (OpenStreetMap)
 ├─ get_weather_alerts       LIVE slot           → Environment Canada (or US NWS) alerts, cached fallback
 ├─ get_air_quality          LIVE slot           → Environment Canada AQHI (wildfire smoke)
 ├─ lookup_guidance          documents slot      → answers only from data/docs/*.md, cites files
 ├─ send_messages            ACTION slot         → requires human approval (require_confirmation)
 ├─ BigQueryToolset          analytics slot      → read-only SQL / BQML over your dataset
 ├─ comms_agent (AgentTool)  multilingual drafts with a Pydantic schema
 └─ viz_agent   (AgentTool)  charts via BuiltInCodeExecutor
 + audit_log callback        every tool call recorded in session state (governance)
```

## Tonight: get it running (15 minutes)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp impact_agent/.env.example impact_agent/.env      # fill in project OR API key
python data/generate_synthetic.py                   # sample Toronto data (synthetic, labelled)
python scripts/smoke_test.py                        # all PASS, no model needed
adk web                                             # run from the REPO ROOT, pick impact_agent
```
Try the prompts under `demo.prompts` in `domain.yaml`. When it asks to approve `send_messages`, that's the human-in-the-loop step.

Push it to your GitHub tonight so teammates can clone it at 8 AM.

## At the event: adapt in about 45 minutes
| Step | What | Time |
|---|---|---|
| 1 | Edit `domain.yaml`: project name, persona, user, mission, geography, routing, out-of-scope | 15 min |
| 2 | Map the event data to the slots (see `docs/DATA_SCENARIOS.md`). Put CSVs in a folder and run `bash data/load_to_bigquery.sh <folder>` | 10 min |
| 3 | Update `data/descriptions.yaml` for the new columns and re-run `python data/apply_descriptions.py` | 10 min |
| 4 | Point `data.tables.*.table` and `columns` at the real names; rewrite the `triage.factors` rules for the new data | 5 min |
| 5 | Set `DATA_BACKEND=bigquery`, run the smoke test, then `adk web` | 5 min |

**Unused slots:** delete the tool from `impact_agent/tools/__init__.py` and its routing line. Fewer, sharper tools route better.
**New capability:** write a function with a clear docstring (the first sentence says *when* to use it), register it, and add a routing line.

## Design choices you can defend to judges
- **Triage is rules, not vibes.** Same input gives the same ranking, and every rank lists its reasons. The LLM explains; it doesn't decide who matters.
- **Emergencies escalate to 911.** These are factor-driven (`escalate: true`) and ranked first.
- **A human approves every outbound action.** ADK pauses `send_messages` until the coordinator approves.
- **Grounding:** numbers come only from tools, live data names its source and time, and documents are cited.
- **The demo can't be broken by Wi-Fi:** live APIs cache the last good response, and a CSV backend replaces BigQuery.
- **Read-only SQL** (`WriteMode.BLOCKED`) and an **audit log** of every tool call.
- **Synthetic data is labelled** (`is_synthetic`). Say so in the demo.

## Gotchas
- Run `adk web` from the **repo root** (the folder that contains `impact_agent/`).
- **BigQuery toolset:** with no credentials it auto-disables with a warning; the CSV tools still work. At the event, run `gcloud auth application-default login`.
- **Model name:** check `MODEL` at kickoff. If it 404s, swap to whatever the organizers list.
- **ADK 2.x:** BigQuery imports live in `google.adk.integrations.bigquery` (the labs' 1.x path still works but is deprecated).
- **Code execution and function tools can't share an agent.** That's why `viz_agent` is a separate AgentTool.
- **Port busy:** `adk web --port 8001`.

## Deploy (if time allows)
```bash
adk deploy agent_engine --project=$GOOGLE_CLOUD_PROJECT --region=us-central1 \
  --staging_bucket=gs://$GOOGLE_CLOUD_PROJECT-staging --display_name="SurgeDesk" \
  --requirements_file=./requirements.txt impact_agent
```
Live tools need outbound internet. CSV mode needs `data/` packaged, so prefer `DATA_BACKEND=bigquery` when deployed.
