"""Generate SYNTHETIC Toronto sample data so the agent works before the event's dataset exists.
Clearly synthetic: replace with real/event data at the hackathon. Deterministic (seeded).

    python data/generate_synthetic.py            # writes data/sample/help_requests.csv + resources.csv
"""
from __future__ import annotations

import csv
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

random.seed(20261020)
OUT = Path(__file__).resolve().parent / "sample"
OUT.mkdir(exist_ok=True)

# Approximate neighbourhood centres (for synthetic points only)
HOODS = {
    "Scarborough Village": (43.738, -79.215), "Malvern": (43.809, -79.222),
    "Glenfield-Jane Heights": (43.756, -79.517), "Rexdale": (43.713, -79.567),
    "Thorncliffe Park": (43.705, -79.348), "St. James Town": (43.670, -79.373),
    "Regent Park": (43.660, -79.361), "South Parkdale": (43.639, -79.437),
    "Flemingdon Park": (43.716, -79.333), "Weston": (43.702, -79.519),
    "Downtown Core": (43.651, -79.383), "Mimico": (43.616, -79.497),
}
LANGS = ["English"] * 6 + ["French", "Simplified Chinese", "Tagalog", "Punjabi", "Spanish", "Tamil", "Arabic"]
NEEDS = {
    "food": ["Out of food until payday, 3 kids at home.", "Need groceries, we are a family of five.",
             "Lost my job, fridge is empty.", "Baby formula running low."],
    "cooling": ["No AC, apartment is 35 degrees.", "My grandmother feels dizzy in the heat.",
                "Can't sleep, too hot, I have a heart condition.", "Need a cool place for my kids today."],
    "evacuation": ["Smoke is bad near us, I use a wheelchair and need a ride out.",
                   "We were told to leave but have no car.", "Need help moving my elderly father."],
    "medical": ["Oxygen supply running low because of the outage.", "Need insulin kept cold, no power.",
                "My son has asthma and the smoke is making it worse."],
}
EMERGENCY = ["My mother fainted and is not responding well.", "Chest pain since this morning, very hot here."]


def jitter(lat: float, lon: float, km: float = 1.5) -> tuple[float, float]:
    return round(lat + random.uniform(-km, km) / 111, 5), round(lon + random.uniform(-km, km) / 80, 5)


def requests_rows(n: int = 200) -> list[dict]:
    now = datetime(2026, 7, 15, 8, 0, tzinfo=timezone.utc)
    rows = []
    for i in range(1, n + 1):
        hood = random.choice(list(HOODS))
        need = random.choices(list(NEEDS), weights=[40, 30, 15, 15])[0]
        msg = random.choice(EMERGENCY) if random.random() < 0.02 else random.choice(NEEDS[need])
        lat, lon = jitter(*HOODS[hood])
        submitted = now - timedelta(minutes=random.randint(5, 24 * 60))
        rows.append({
            "request_id": f"R{i:04d}", "submitted_at": submitted.isoformat(), "neighbourhood": hood,
            "lat": lat, "lon": lon, "need_type": need, "message": msg, "language": random.choice(LANGS),
            "household_size": random.randint(1, 7),
            "has_children_under_5": random.random() < 0.22, "has_senior_75_plus": random.random() < 0.18,
            "mobility_limited": random.random() < 0.12, "medical_need": need == "medical" or random.random() < 0.06,
            "no_phone": random.random() < 0.08, "lives_alone": random.random() < 0.25,
            "hours_waiting": round((now - submitted).total_seconds() / 3600, 1), "status": "open",
            "is_synthetic": True,
        })
    return rows


def resources_rows() -> list[dict]:
    cats = {"cool_space": ("Community Centre cool space", "09:00-21:00", 120),
            "food_bank": ("Neighbourhood food bank", "10:00-16:00 Tue/Thu/Sat", 300),
            "shelter": ("24h respite site", "24h", 60),
            "clinic": ("Community health centre", "08:30-20:00", 40),
            "evacuation_centre": ("Reception centre", "24h when activated", 400)}
    rows, i = [], 1
    for hood, (lat, lon) in HOODS.items():
        for cat, (label, hours, cap) in cats.items():
            if random.random() < 0.6:
                la, lo = jitter(lat, lon, 1.0)
                rows.append({"resource_id": f"S{i:03d}", "name": f"{hood} {label} (sample)", "category": cat,
                             "lat": la, "lon": lo, "address": f"{random.randint(10, 999)} Sample St, {hood}",
                             "hours": hours, "capacity": cap, "accessible": random.random() < 0.8,
                             "languages": random.choice(["English", "English; French", "English; Tamil",
                                                         "English; Simplified Chinese", "English; Arabic"]),
                             "is_synthetic": True})
                i += 1
    return rows


def write(name: str, rows: list[dict]) -> None:
    path = OUT / f"{name}.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows):>4} rows → {path}")


if __name__ == "__main__":
    write("help_requests", requests_rows())
    write("resources", resources_rows())
