#!/usr/bin/env bash
# Load every CSV in a folder into BigQuery, then apply column descriptions.
#   bash data/load_to_bigquery.sh                 # loads data/sample/*.csv
#   bash data/load_to_bigquery.sh path/to/csvs    # loads the event's / your own CSVs
set -euo pipefail
PROJECT="${GOOGLE_CLOUD_PROJECT:?set GOOGLE_CLOUD_PROJECT}"
DATASET="${DATASET:-$(python -c "import yaml;print(yaml.safe_load(open('domain.yaml'))['data']['dataset'])")}"
LOCATION="${BQ_LOCATION:-US}"
SRC="${1:-data/sample}"

bq --location="$LOCATION" mk -f --dataset "$PROJECT:$DATASET" >/dev/null 2>&1 || true
for f in "$SRC"/*.csv; do
  t="$(basename "$f" .csv)"
  echo "Loading $f → $PROJECT:$DATASET.$t"
  bq load --replace --autodetect --source_format=CSV "$PROJECT:$DATASET.$t" "$f"
done
python data/apply_descriptions.py
echo "Done. Try: bq query --use_legacy_sql=false 'SELECT need_type, COUNT(*) n FROM \`$PROJECT.$DATASET.help_requests\` GROUP BY 1'"
