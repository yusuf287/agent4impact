# SAMPLE guidance (replace with official documents at the event)

## Extreme heat — who is most at risk
Older adults, infants and young children, people with chronic illness (heart, lung, kidney), people with
limited mobility, people who live alone, and people without air conditioning are at highest risk.

## Extreme heat — what to do
Go to an air-conditioned cool space, drink water often, check on neighbours who live alone.
Call 911 for confusion, fainting, chest pain, or a very high body temperature.

## Wildfire smoke — what to do
When the AQHI is high (7+), reduce outdoor activity. People with asthma or heart conditions should keep
medication close. Use a clean-air space such as a library or community centre if your home is smoky.
