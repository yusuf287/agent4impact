"""Write column descriptions from data/descriptions.yaml into BigQuery table schemas."""
import os
from pathlib import Path

import yaml
from google.cloud import bigquery

root = Path(__file__).resolve().parent.parent
dataset = yaml.safe_load(open(root / "domain.yaml"))["data"]["dataset"]
project = os.environ["GOOGLE_CLOUD_PROJECT"]
client = bigquery.Client(project=project)

for table_name, cols in yaml.safe_load(open(root / "data" / "descriptions.yaml")).items():
    ref = f"{project}.{dataset}.{table_name}"
    try:
        table = client.get_table(ref)
    except Exception as e:
        print(f"skip {ref}: {e}")
        continue
    table.schema = [
        bigquery.SchemaField(f.name, f.field_type, mode=f.mode, description=cols.get(f.name, f.description),
                             fields=f.fields)
        for f in table.schema
    ]
    client.update_table(table, ["schema"])
    print(f"described {ref} ({sum(1 for f in table.schema if f.description)} columns)")
