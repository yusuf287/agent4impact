"""Loads domain.yaml + environment. Every other module imports from here."""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent  # repo root (contains domain.yaml)

try:  # .env is auto-loaded by `adk web`/`adk run`; this covers plain `python` runs too
    from dotenv import load_dotenv

    load_dotenv(ROOT / "impact_agent" / ".env")
    load_dotenv(ROOT / ".env")
except ImportError:
    pass


@lru_cache(maxsize=1)
def domain() -> dict:
    path = Path(os.getenv("DOMAIN_FILE", ROOT / "domain.yaml"))
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


MODEL = os.getenv("MODEL", "gemini-3-flash-preview")       # check the model list at the event
PROJECT = os.getenv("GOOGLE_CLOUD_PROJECT", "")
DATA_BACKEND = os.getenv("DATA_BACKEND", "csv").lower()      # "bigquery" at the event, "csv" offline
ENABLE_BQ_TOOLSET = os.getenv("ENABLE_BQ_TOOLSET", "true").lower() == "true"


def dataset() -> str:
    return domain()["data"]["dataset"]


def table_cfg(key: str) -> dict:
    return domain()["data"]["tables"][key]


def fq_table(key: str) -> str:
    """Fully qualified BigQuery table name, e.g. `proj.impact_data.help_requests`."""
    return f"`{PROJECT}.{dataset()}.{table_cfg(key)['table']}`"


def csv_path(key: str) -> Path:
    return ROOT / domain()["data"]["csv_dir"] / f"{table_cfg(key)['table']}.csv"
