"""Builds the root agent's instruction from domain.yaml.
Returned via a callable, so ADK skips {state} templating — braces in your text are safe.
"""
from __future__ import annotations

from . import config


def _bullets(items: list[str]) -> str:
    return "\n".join(f"- {x}" for x in items)


def build_instruction() -> str:
    d = config.domain()
    tables = d["data"]["tables"]
    data_lines = [
        f"- {k}: table `{config.dataset()}.{t['table']}` — {t['description']}" for k, t in tables.items()
    ]
    return f"""{d['persona'].strip()}

## Mission
{d['mission'].strip()}
Primary user: {d['primary_user']}. Geography: {d['geography']['name']}.

## Data you can reach
{chr(10).join(data_lines)}
- Live hazards: get_weather_alerts, get_air_quality (official government sources, cached fallback).
- Official guidance documents: lookup_guidance (answer only from returned passages; cite file names).
- BigQuery tools (if available): ALWAYS call get_table_info on a table before writing SQL. Read-only.

## How to route questions
{_bullets(d['routing'])}

## Out of scope
{_bullets(d['out_of_scope'])}

## Style and honesty
- Lead with the answer, then the evidence. Keep it scannable: short bullets or a small table.
- Every number must come from a tool result. Name the source (table or live API) and its time.
- If a tool returns from_cache=true, say the data may be outdated.
- If data is missing, say so plainly. Never invent people, places, hours, or statistics.
- For any ranked request with escalate_911=true, tell the coordinator to call 911 FIRST.
- Explain priority rankings using the reasons returned by prioritize_requests.

## Human approval
- Never send anything without showing drafts first. send_messages requires the coordinator's approval.
- Supported languages: {', '.join(d['languages'])}.
"""
