"""Root agent. ADK discovers `root_agent` in this file.

Architecture:
  root_agent (coordinator; routing rules from domain.yaml)
   ├─ domain tools:  prioritize_requests · find_nearest_resources · geocode_address
   │                 get_weather_alerts · get_air_quality · send_messages (human approval)
   ├─ BigQueryToolset (read-only SQL over your dataset; auto-disabled without credentials)
   ├─ AgentTool(comms_agent)  → multilingual drafts, Pydantic schema
   └─ AgentTool(viz_agent)    → charts via BuiltInCodeExecutor
"""
from __future__ import annotations

import logging

from google.adk.agents import Agent
from google.adk.tools.agent_tool import AgentTool

from . import config
from .callbacks import audit_tool_call
from .prompts import build_instruction
from .sub_agents import comms_agent, viz_agent
from .tools import DOMAIN_TOOLS

log = logging.getLogger(__name__)


def _bigquery_toolset():
    """Read-only BigQuery toolset (list datasets/tables, get_table_info, execute_sql)."""
    if not config.ENABLE_BQ_TOOLSET:
        return None
    try:
        import google.auth
        from google.adk.integrations.bigquery import BigQueryCredentialsConfig, BigQueryToolset
        from google.adk.integrations.bigquery.config import BigQueryToolConfig, WriteMode

        creds, _ = google.auth.default()
        return BigQueryToolset(
            credentials_config=BigQueryCredentialsConfig(credentials=creds),
            bigquery_tool_config=BigQueryToolConfig(write_mode=WriteMode.BLOCKED),
        )
    except Exception as e:  # no ADC / no GCP libs → keep running with CSV tools only
        log.warning("BigQuery toolset disabled: %s", e)
        return None


_tools = [*DOMAIN_TOOLS, AgentTool(agent=comms_agent), AgentTool(agent=viz_agent)]
_bq = _bigquery_toolset()
if _bq is not None:
    _tools.append(_bq)

root_agent = Agent(
    name="impact_agent",
    model=config.MODEL,
    description=config.domain()["project"]["tagline"],
    instruction=lambda ctx: build_instruction(),  # callable → no {state} templating surprises
    tools=_tools,
    after_tool_callback=audit_tool_call,
)
