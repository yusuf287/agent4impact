"""Governance: record every tool call in session state (visible in the adk web State tab).
Great for the "how do we know what the agent did?" judge question.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional


def audit_tool_call(tool, args: dict[str, Any], tool_context, tool_response: dict) -> Optional[dict]:
    entry = {
        "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "tool": getattr(tool, "name", str(tool)),
        "args": {k: (str(v)[:120]) for k, v in (args or {}).items()},
        "status": (tool_response or {}).get("status") if isinstance(tool_response, dict) else "ok",
    }
    log = tool_context.state.get("audit_log", [])
    log.append(entry)
    tool_context.state["audit_log"] = log[-50:]
    return None  # don't modify the tool result
