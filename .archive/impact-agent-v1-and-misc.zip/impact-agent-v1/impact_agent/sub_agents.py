"""Specialist agents, wrapped as AgentTools by the root agent.

- comms_agent: multilingual drafts with a fixed Pydantic schema (UI-friendly, consistent).
- viz_agent:   charts via BuiltInCodeExecutor. Code execution can't share an agent with function
               tools, so it lives in its own agent and is called as a tool (pattern from the labs).
"""
from __future__ import annotations

from google.adk.agents import Agent
from google.adk.code_executors import BuiltInCodeExecutor
from pydantic import BaseModel, Field

from . import config


class DraftMessage(BaseModel):
    recipient_id: str = Field(description="ID of the request/person this message is for.")
    language: str = Field(description="Language the message is written in.")
    channel: str = Field(description="'sms' (<= 300 characters) or 'email'.")
    text: str = Field(description="The message text in the recipient's language.")
    english_gloss: str = Field(description="Short English translation so the coordinator can review it.")


class DraftBatch(BaseModel):
    messages: list[DraftMessage]


comms_agent = Agent(
    name="comms_agent",
    model=config.MODEL,
    description="Drafts short, plain-language, multilingual messages (SMS/email) to people needing help.",
    instruction=(
        "Write clear, warm, plain-language messages for people in a crisis. "
        "Use the recipient's language if given. SMS must be under 300 characters. "
        "Include only facts provided to you (place name, address, hours, what to bring). "
        "Never promise guaranteed service. If the request suggests a medical emergency, "
        "the message must tell them to call 911 first. Always include an English gloss."
    ),
    output_schema=DraftBatch,
)

viz_agent = Agent(
    name="viz_agent",
    model=config.MODEL,
    description="Creates a chart (bar, line, map-like scatter) from data provided in the request.",
    instruction=(
        "Write and run matplotlib code to chart ONLY the data you are given. "
        "Clear title, labelled axes with units, readable fonts, colour-blind-safe palette, "
        "plt.tight_layout(). Prefer horizontal bars for rankings. Then state the one key takeaway."
    ),
    code_executor=BuiltInCodeExecutor(),
)
