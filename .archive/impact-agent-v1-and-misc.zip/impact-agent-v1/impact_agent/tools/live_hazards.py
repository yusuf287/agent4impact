"""Live hazard data. Canada: Environment Canada GeoMet-OGC-API. US: National Weather Service.
Every successful call is cached to disk so a Wi-Fi failure during the demo falls back to the last good answer.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import requests

from .. import config

CACHE_DIR = config.ROOT / ".cache"
ECCC = "https://api.weather.gc.ca/collections"


def _cached_get(name: str, url: str, params: dict | None = None, headers: dict | None = None) -> tuple[dict, bool]:
    CACHE_DIR.mkdir(exist_ok=True)
    path = CACHE_DIR / f"{name}.json"
    try:
        r = requests.get(url, params=params, headers=headers, timeout=12)
        r.raise_for_status()
        data = r.json()
        path.write_text(json.dumps(data))
        return data, False
    except Exception:
        if path.exists():
            return json.loads(path.read_text()), True
        raise


def _bbox() -> str:
    return ",".join(str(x) for x in config.domain()["geography"]["bbox"])


def get_weather_alerts() -> dict:
    """Get CURRENT official weather alerts (heat, smoke, storm, flood, wind) for the configured city.

    Use for any "right now" hazard question before giving advice about outdoor travel or evacuation.

    Returns:
        dict with status, source, retrieved_at, from_cache flag, and a list of alerts
        (name, type, headline/text excerpt, start/end times). An empty list means no active alerts.
    """
    geo = config.domain()["geography"]
    try:
        if geo.get("hazards_provider", "eccc") == "nws":
            data, cached = _cached_get(
                "nws_alerts", "https://api.weather.gov/alerts/active",
                params={"point": geo["nws_point"]}, headers={"User-Agent": "impact-agent-hackathon"})
            alerts = [{
                "name": p.get("event"), "severity": p.get("severity"), "headline": p.get("headline"),
                "area": p.get("areaDesc"), "starts": p.get("effective"), "ends": p.get("expires"),
                "instruction": (p.get("instruction") or "")[:500],
            } for p in (f["properties"] for f in data.get("features", []))]
            source = "US National Weather Service (api.weather.gov)"
        else:
            data, cached = _cached_get(
                "eccc_alerts", f"{ECCC}/weather-alerts/items",
                params={"f": "json", "bbox": _bbox(), "limit": 50})
            alerts = [{
                "name": p.get("alert_name_en"), "type": p.get("alert_type"),
                "text_excerpt": (p.get("alert_text_en") or "")[:600],
                "published": p.get("publication_datetime"), "ends": p.get("event_end_datetime"),
            } for p in (f["properties"] for f in data.get("features", []))]
            source = "Environment and Climate Change Canada (api.weather.gc.ca)"
    except Exception as e:
        return {"status": "error", "error_message": f"Live alerts unavailable and no cache: {e}"}

    return {"status": "success", "source": source, "from_cache": cached,
            "retrieved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "alert_count": len(alerts), "alerts": alerts}


def get_air_quality() -> dict:
    """Get the latest observed Air Quality Health Index (AQHI) readings for stations in the configured city.

    Use for wildfire smoke or air-pollution questions (Canada only). AQHI scale: 1-3 low risk,
    4-6 moderate, 7-10 high, 10+ very high. High-risk groups: seniors, children, people with
    heart or lung conditions.

    Returns:
        dict with status, source, from_cache flag, and readings (station, aqhi, risk_level, observed_at).
    """
    if config.domain()["geography"].get("hazards_provider", "eccc") != "eccc":
        return {"status": "unavailable", "error_message": "AQHI is a Canadian index; no US source configured."}
    try:
        data, cached = _cached_get(
            "eccc_aqhi", f"{ECCC}/aqhi-observations-realtime/items",
            params={"f": "json", "latest": "true", "bbox": _bbox(), "limit": 50})
    except Exception as e:
        return {"status": "error", "error_message": f"AQHI unavailable and no cache: {e}"}

    def level(v: float) -> str:
        return "low" if v <= 3 else "moderate" if v <= 6 else "high" if v <= 10 else "very high"

    readings = [{
        "station": p.get("location_name_en"), "aqhi": p.get("aqhi"),
        "risk_level": level(float(p.get("aqhi") or 0)), "observed_at": p.get("observation_datetime"),
    } for p in (f["properties"] for f in data.get("features", []))]
    return {"status": "success", "source": "Environment and Climate Change Canada AQHI",
            "from_cache": cached, "readings": readings}
