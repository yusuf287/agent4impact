"""Location tools: nearest resources (haversine) + optional address geocoding (OpenStreetMap Nominatim)."""
from __future__ import annotations

import math

import requests

from .. import config
from ..data_access import col, fetch_rows


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def find_nearest_resources(lat: float, lon: float, category: str = "", limit: int = 3) -> dict:
    """Find the nearest places that can help (food bank, cool space, shelter, clinic, evacuation centre).

    Use this when the user asks where someone should go, or to match a prioritized request to a site.
    If you only have an address, call geocode_address first to get lat/lon.

    Args:
        lat: Latitude of the person.
        lon: Longitude of the person.
        category: Optional resource category filter (e.g. "cool_space", "food_bank", "shelter",
            "clinic", "evacuation_centre"). Empty = any category.
        limit: Number of results (default 3).

    Returns:
        dict with status and a list of resources sorted by straight-line distance_km.
    """
    try:
        rows = fetch_rows("resources")
    except Exception as e:
        return {"status": "error", "error_message": str(e)}

    c_lat, c_lon, c_cat = col("resources", "lat"), col("resources", "lon"), col("resources", "category")
    if category:
        rows = [r for r in rows if category.lower() in str(r.get(c_cat, "")).lower()]
    for r in rows:
        r["distance_km"] = round(_haversine_km(lat, lon, float(r[c_lat]), float(r[c_lon])), 2)
    rows.sort(key=lambda r: r["distance_km"])
    return {
        "status": "success",
        "note": "Straight-line distance; confirm hours/capacity before sending someone.",
        "resources": rows[: max(1, int(limit))],
    }


def geocode_address(address: str) -> dict:
    """Convert a street address or place name into latitude/longitude.

    Use before find_nearest_resources when the user gives an address instead of coordinates.

    Args:
        address: Free-text address, e.g. "100 Queen St W". The configured city is appended automatically.

    Returns:
        dict with status, lat, lon, display_name.
    """
    city = config.domain()["geography"]["name"]
    q = address if city.lower() in address.lower() else f"{address}, {city}"
    try:
        resp = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={"q": q, "format": "json", "limit": 1},
            headers={"User-Agent": "impact-agent-hackathon/0.1"},
            timeout=10,
        )
        resp.raise_for_status()
        hits = resp.json()
    except Exception as e:
        return {"status": "error", "error_message": f"Geocoding failed: {e}"}
    if not hits:
        return {"status": "not_found", "error_message": f"No match for '{q}'"}
    h = hits[0]
    return {"status": "success", "lat": float(h["lat"]), "lon": float(h["lon"]), "display_name": h["display_name"]}
