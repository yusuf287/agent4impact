"""Explainable triage: rules from domain.yaml, not LLM judgment. Same input -> same ranking."""
from __future__ import annotations

from typing import Any

from .. import config
from ..data_access import col, fetch_rows


def _matches(value: Any, op: str, target: Any) -> bool:
    if value is None:
        return False
    op = "true" if op is True else str(op).lower()  # YAML parses `op: true` as a boolean
    if op == "true":
        return bool(value) is True
    if op == "eq":
        return value == target
    if op == "ne":
        return value != target
    if op == "gte":
        return float(value) >= float(target)
    if op == "lte":
        return float(value) <= float(target)
    if op == "in":
        return value in target
    if op == "contains":
        text = str(value).lower()
        return any(t.lower() in text for t in (target if isinstance(target, list) else [target]))
    raise ValueError(f"Unknown op '{op}' in domain.yaml triage factors")


def score_row(row: dict) -> tuple[int, list[str], bool]:
    score, reasons, escalate = 0, [], False
    for f in config.domain()["triage"]["factors"]:
        if _matches(row.get(f["field"]), f["op"], f.get("value")):
            score += int(f["weight"])
            reasons.append(f"+{f['weight']} {f['reason']}")
            escalate = escalate or bool(f.get("escalate"))
    return score, reasons, escalate


def prioritize_requests(top_n: int = 10, need_type: str = "", neighbourhood: str = "") -> dict:
    """Rank open help requests by explainable risk score so the coordinator helps the most vulnerable first.

    Use this whenever the user asks who to help first, to triage, or to prioritize requests.
    Scoring rules are fixed in domain.yaml, so every rank comes with the reasons behind it.

    Args:
        top_n: How many top-priority requests to return (default 10).
        need_type: Optional filter, e.g. "food", "cooling", "evacuation", "medical". Empty = all.
        neighbourhood: Optional neighbourhood name filter. Empty = all.

    Returns:
        dict with status, total_open, emergency_count, and ranked items (id, score, reasons, row fields).
    """
    try:
        rows = fetch_rows("requests")
    except Exception as e:  # surface errors to the model so it can explain them
        return {"status": "error", "error_message": str(e)}

    nb_col = col("requests", "neighbourhood")
    if need_type:
        rows = [r for r in rows if str(r.get("need_type", "")).lower() == need_type.lower()]
    if neighbourhood:
        rows = [r for r in rows if neighbourhood.lower() in str(r.get(nb_col, "")).lower()]

    ranked = []
    for r in rows:
        s, why, esc = score_row(r)
        ranked.append({"id": r.get(col("requests", "id")), "score": s, "reasons": why,
                       "escalate_911": esc, **r})
    ranked.sort(key=lambda x: (x["escalate_911"], x["score"]), reverse=True)  # emergencies first

    return {
        "status": "success",
        "total_open": len(rows),
        "emergency_count": sum(1 for x in ranked if x["escalate_911"]),
        "scoring_note": "Deterministic rules from domain.yaml; a human makes the final call.",
        "items": ranked[: max(1, int(top_n))],
    }
