"""Tool registry. Add a new tool = write a function with a clear docstring, then list it here."""
from google.adk.tools import FunctionTool

from .actions import send_messages
from .geo import find_nearest_resources, geocode_address
from .guidance import lookup_guidance
from .live_hazards import get_air_quality, get_weather_alerts
from .triage import prioritize_requests

DOMAIN_TOOLS = [
    FunctionTool(prioritize_requests),
    FunctionTool(find_nearest_resources),
    FunctionTool(geocode_address),
    FunctionTool(get_weather_alerts),
    FunctionTool(get_air_quality),
    FunctionTool(lookup_guidance),
    # Human-in-the-loop: ADK pauses and asks the user to approve before running.
    FunctionTool(send_messages, require_confirmation=True),
]
