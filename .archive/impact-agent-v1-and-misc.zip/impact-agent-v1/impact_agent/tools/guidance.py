"""Document slot: answer from official guidance files (plans, health advice, rules) in data/docs/*.md|*.txt.
Simple keyword scoring — swap for a Vertex AI Search / Gemini Enterprise data store if docs are large.
"""
from __future__ import annotations

import re

from .. import config

DOCS = config.ROOT / "data" / "docs"


def lookup_guidance(question: str, max_passages: int = 3) -> dict:
    """Find passages in official guidance documents (emergency plans, public-health advice, program rules).

    Use for "what should people do / what is the rule / what does the plan say" questions.
    Quote or paraphrase ONLY the returned passages and cite their file names.

    Args:
        question: The user's question in plain words.
        max_passages: Number of passages to return (default 3).

    Returns:
        dict with status and passages (source file, text). Empty passages = not covered by documents.
    """
    terms = {w for w in re.findall(r"[a-zA-Z]{4,}", question.lower())}
    scored = []
    for path in sorted(DOCS.glob("*")):
        if path.suffix.lower() not in (".md", ".txt"):
            continue
        for chunk in re.split(r"\n\s*\n", path.read_text(encoding="utf-8")):
            hits = sum(chunk.lower().count(t) for t in terms)
            if hits:
                scored.append((hits, path.name, chunk.strip()[:1200]))
    scored.sort(reverse=True)
    passages = [{"source": s, "text": t} for _, s, t in scored[: max(1, int(max_passages))]]
    return {"status": "success", "passages": passages,
            "note": "No matching guidance — say the documents don't cover this." if not passages else ""}
