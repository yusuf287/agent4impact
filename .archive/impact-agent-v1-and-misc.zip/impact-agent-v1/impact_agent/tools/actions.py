"""Actions with consequences. Wrapped with require_confirmation=True in tools/__init__.py,
so ADK pauses and the human must approve in the UI before this runs (human-in-the-loop).
Sending is SIMULATED (written to outbox.jsonl) — say so in the demo; swap in Twilio/email later.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

from google.adk.tools.tool_context import ToolContext

from .. import config

OUTBOX = config.ROOT / "outbox.jsonl"


def send_messages(messages: list[dict], tool_context: ToolContext) -> dict:
    """Send approved messages (SMS/email) to people. ALWAYS requires human approval first.

    Only call after drafts have been shown to the coordinator. Never call for unreviewed text.

    Args:
        messages: List of objects with keys: recipient_id, language, channel ("sms" or "email"), text.

    Returns:
        dict with status, sent_count, and where the messages were recorded.
    """
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with open(OUTBOX, "a", encoding="utf-8") as f:
        for m in messages:
            f.write(json.dumps({**m, "sent_at": now, "simulated": True}, ensure_ascii=False) + "\n")
    log = tool_context.state.get("sent_log", [])
    log.extend(m.get("recipient_id") for m in messages)
    tool_context.state["sent_log"] = log
    return {"status": "success", "sent_count": len(messages),
            "note": f"Simulated send recorded in {OUTBOX.name} (no real SMS in this prototype)."}
