"""One read path for tools. BigQuery at the event; CSV fallback keeps the demo alive offline."""
from __future__ import annotations

import csv
from typing import Any

from . import config


def _coerce(v: str) -> Any:
    if v is None or v == "":
        return None
    low = v.lower()
    if low in ("true", "false"):
        return low == "true"
    try:
        return int(v)
    except ValueError:
        pass
    try:
        return float(v)
    except ValueError:
        return v


def fetch_rows(key: str, limit: int = 5000) -> list[dict]:
    """Return rows of a configured table ('requests' or 'resources') as dicts."""
    if config.DATA_BACKEND == "bigquery":
        from google.cloud import bigquery  # imported lazily so CSV mode needs no GCP libs

        client = bigquery.Client(project=config.PROJECT or None)
        sql = f"SELECT * FROM {config.fq_table(key)} LIMIT {int(limit)}"
        return [dict(r) for r in client.query(sql).result()]

    path = config.csv_path(key)
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run `python data/generate_synthetic.py` or set DATA_BACKEND=bigquery."
        )
    with open(path, newline="", encoding="utf-8") as f:
        return [{k: _coerce(v) for k, v in row.items()} for row, _ in zip(csv.DictReader(f), range(limit))]


def col(key: str, logical: str) -> str:
    """Map a logical column name (lat, lon, id...) to the real column in domain.yaml."""
    return config.table_cfg(key)["columns"].get(logical, logical)
