"""Run before the event and right after adapting domain.yaml:   python scripts/smoke_test.py
Checks: agent builds, tools registered, prompt renders, triage/geo work on data, live APIs respond.
Needs no model credentials. Exit code 1 on any failure.
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("DATA_BACKEND", "csv")

ok = True


def check(name, fn):
    global ok
    try:
        msg = fn()
        print(f"  PASS  {name}" + (f" — {msg}" if msg else ""))
    except Exception as e:
        ok = False
        print(f"  FAIL  {name} — {type(e).__name__}: {e}")


print("impact-agent smoke test\n")

from impact_agent import config  # noqa: E402
from impact_agent.agent import root_agent  # noqa: E402
from impact_agent.prompts import build_instruction  # noqa: E402
from impact_agent.tools.geo import find_nearest_resources  # noqa: E402
from impact_agent.tools.live_hazards import get_air_quality, get_weather_alerts  # noqa: E402
from impact_agent.tools.triage import prioritize_requests  # noqa: E402

check("root_agent builds", lambda: f"{root_agent.name}, model={root_agent.model}")
check("tools registered", lambda: ", ".join(getattr(t, "name", type(t).__name__) for t in root_agent.tools))
check("prompt renders", lambda: f"{len(build_instruction())} chars")


def _triage():
    r = prioritize_requests(top_n=3)
    assert r["status"] == "success", r
    top = r["items"][0]
    return f"{r['total_open']} open, {r['emergency_count']} escalate-911, top={top['id']} score={top['score']}"


check("prioritize_requests", _triage)


def _geo():
    c = config.domain()["geography"]["center"]
    r = find_nearest_resources(c["lat"], c["lon"], category="cool_space", limit=2)
    assert r["status"] == "success" and r["resources"], r
    return f"nearest={r['resources'][0]['name']} ({r['resources'][0]['distance_km']} km)"


check("find_nearest_resources", _geo)


def _alerts():
    r = get_weather_alerts()
    assert r["status"] == "success", r
    return f"{r['alert_count']} active alerts (cache={r['from_cache']})"


def _aqhi():
    r = get_air_quality()
    assert r["status"] in ("success", "unavailable"), r
    return ", ".join(f"{x['station']}={x['aqhi']}" for x in r.get("readings", [])[:3]) or r.get("error_message")


check("get_weather_alerts (live)", _alerts)
check("get_air_quality (live)", _aqhi)

print("\nALL GOOD — next: `adk web` from the repo root" if ok else "\nFix the FAIL lines above.")
sys.exit(0 if ok else 1)
