# What data they might give you, and where it plugs in

Every likely dataset falls into one of **six shapes**. Each shape has a slot in the scaffold,
so tomorrow is mapping, not re-architecting.

| Shape | Examples you might receive | Slot in scaffold | What the agent can do with it |
|---|---|---|---|
| **1. People / cases / requests** (one row per person, household, call, or ticket) | 311 service requests, food bank client visits, ER/clinic visits, evacuation registrations, shelter intake | `requests` table → `prioritize_requests` | Triage, prioritize, find who's left behind |
| **2. Places / resources** (one row per site) | Food banks and pantries, cooling centres, shelters, hospitals, clinics, evacuation centres, grocery stores, transit stops | `resources` table → `find_nearest_resources` | Nearest suitable help, coverage gaps, capacity |
| **3. Area statistics** (one row per neighbourhood, tract, ZIP, or county) | Census income, age, language; health measures (e.g., CDC PLACES-style chronic disease rates); food-access / food-desert indicators; heat vulnerability | BigQuery toolset (SQL) + optional BQML model | "Which areas are most vulnerable?", vulnerability index, hotspot ranking |
| **4. Time series** (date × place × value) | Daily temperatures, AQHI, case counts, food bank visits per week, 311 volume | BigQuery toolset + BQML `ARIMA_PLUS` forecast via `execute_sql` | "Will demand spike next week?", early warning |
| **5. Live feeds / APIs** | Weather alerts, air quality, wildfire hotspots, transit status, road closures | `live_hazards.py` pattern (cached GET) | "What's happening right now?" |
| **6. Documents** | Emergency plans, public-health guidance, program eligibility rules | `data/docs/` → `lookup_guidance` | Grounded "what should we do" answers with citations |

## Mapping in 10 minutes
1. For each table they give you, label its shape (1–6) and write it on a whiteboard.
2. **The table with people** goes to the `requests` slot. **The table with places** goes to the `resources` slot. Edit `columns:` in `domain.yaml` to point at the real column names.
3. **Area statistics and time series** need no code. Load them and describe the columns. The BigQuery toolset will query them.
4. **No people table?** Generate a synthetic request stream with `data/generate_synthetic.py` and edit it to match the challenge. Say "synthetic" in the demo.
5. **No places table?** Use OpenStreetMap or open-data portals (Toronto Open Data has the Heat Relief Network cool spaces, wards, and neighbourhood profiles).

## Quick BQML recipes (run via execute_sql or in BigQuery Studio)
```sql
-- Vulnerability index (no labels needed): cluster areas by risk profile
CREATE OR REPLACE MODEL impact_data.area_clusters OPTIONS(model_type='KMEANS', num_clusters=4,
  standardize_features=TRUE) AS SELECT * EXCEPT(area_id, area_name) FROM impact_data.area_stats;

-- Demand forecast: e.g., weekly food bank visits per site
CREATE OR REPLACE MODEL impact_data.demand_forecast OPTIONS(model_type='ARIMA_PLUS',
  time_series_timestamp_col='week', time_series_data_col='visits', time_series_id_col='site_id')
AS SELECT week, site_id, visits FROM impact_data.weekly_visits;
SELECT * FROM ML.FORECAST(MODEL impact_data.demand_forecast, STRUCT(4 AS horizon));
```

## Pre-verified live sources (free, no key)
- **Canada alerts:** `https://api.weather.gc.ca/collections/weather-alerts/items?f=json&bbox=...`
- **Canada AQHI:** `https://api.weather.gc.ca/collections/aqhi-observations-realtime/items?f=json&latest=true&bbox=...`
- **US alerts:** `https://api.weather.gov/alerts/active?point=LAT,LON` (send a User-Agent header)
- **Geocoding:** OpenStreetMap Nominatim (light use only)

## Questions for the mentor at kickoff
1. Which table or column do you consider most important for this challenge?
2. Can we add outside open data or live APIs?
3. Which model names and which BigQuery region should we use?
4. How will judging work: live demo, slides, or both? How long?
